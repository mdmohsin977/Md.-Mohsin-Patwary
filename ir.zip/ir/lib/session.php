<?php

class session{

	public function _construct(){

	}
}
?>
