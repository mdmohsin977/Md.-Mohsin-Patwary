<?php include 'inc/header.php';  ?>
	


<div class="panel panel-default">
	<div class="panel-heading">
		<h2>User List <span class="pull-right"><strong>Welcome!</strong>Delower</span></h2>
	</div>
	
	<div class="panel-body">
		<table class="table table-striped">
			<th width="20%">Serial</th>
			<th width="20%">Name</th>
			<th width="20%">User Name</th>
			<th width="20%">Email Address</th>
			<th width="20%">Action</th>
			
			<tr>
				<td>01</td>
				<td>Delower J Imran</td>
				<td>Imran</td>
				<td>imran@gmail.com</td>
				<td>
					<a class="btn btn-primary" href="#">View</a>
				</td>
			</tr>
			
			<tr>
				<td>02</td>
				<td>Mohsin J Imran</td>
				<td>Mohsin</td>
				<td>mohsin@gmail.com</td>
				<td>
					<a class="btn btn-primary" href="#">View</a>
				</td>
			</tr>
			
			<tr>
				<td>03</td>
				<td>Kamal J Imran</td>
				<td>kamal</td>
				<td>kamal@gmail.com</td>
				<td>
					<a class="btn btn-primary" href="#">View</a>
				</td>
			</tr>
			
		</table>
	</div>
</div>


<?php include 'inc/footer.php';  ?>
