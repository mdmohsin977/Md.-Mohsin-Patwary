<?php include 'inc/header.php';  ?>
<?php
echo "Insert logout page !!";
?>
<?php include 'inc/footer.php';  ?>